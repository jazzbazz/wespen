/**VARIABELEN EN DATATYPES**/

var voorNaam = 'Tom'; //string
console.log(voorNaam);
var familieNaam = 'Vanhoutte'; //string
console.log(familieNaam);
var geboorteJaar = 1973; //number
console.log(geboorteJaar);
var functie = 'Docent';//string
console.log(functie);
var gehuwd = true; //boolean
console.log(gehuwd);
var niets; //undefined
console.log(niets);
//toekennen van inhoud aan een undefined variabele
niets = 'niets is niet langer undefined';
console.log(niets);
/** concatenateren (samenvoegen) output als string**/
console.log(voorNaam + ' ' + familieNaam + ' is een ' + functie + ' ' + 'Full Stack Developer' + ' en is ' + gehuwd);

/**PROMPT**/
var voorNaam = prompt('Geef je voornaam in:')
console.log(voorNaam);

/**TYPEOF DATATYPE**/
console.log(typeof voorNaam);
console.log(typeof gehuwd);

/**OPERATOREN**/
/**REKENKUNDIGE OPERATOREN**/
var getal1, getal2, quotient, verschil, som, product
getal1 = 8;
getal2 = 4;

som = getal1 + getal2; //som
verschil = getal1 - getal2; //verschil
product = getal1 * getal2; // vermenigvuldiging
quotient = getal1 / getal2; //deling

console.log('Som:' + ' ' + som);
console.log('Verschil:' + ' ' + verschil);
console.log('Product:' + ' ' + product);
console.log('Quotient:' + ' ' + quotient);

/**VOORRANGSREGELS**/
console.log(getal1 + getal2 * getal1);
console.log((getal1 + getal2) * getal1);

/**SHORTHAND NOTATIES**/
x = 5
y = 6

x += y // x= x + y
console.log('x:' + ' ' + x);

/**LOGISCHE OPERATOREN**/
var grootsteKleinste = getal1 > getal2
console.log(grootsteKleinste);
grootsteKleinste = getal2 > getal1 //grootsteKleinste overschreven
console.log(grootsteKleinste);

var getal3 = '5'; //string datatype
var getal4 = 5; //number datatype
var gelijk = getal3 == getal4;
console.log(gelijk);
gelijk = getal3 === getal4;//verschillend datatype
console.log(gelijk);

/**CONTROLESTRUCTEREN: IF-ELSE STATEMENT**/
var getal5 = prompt('Geef een eerste getal in');
var getal6 = prompt('Geef een tweede getal in');
if(getal5 > getal6){
	console.log(getal5 + ' is groter dan ' + getal6);
}else{
	console.log(getal5 + ' is kleiner dan ' + getal6);
}

/**CONTROLESTRUCTUREN: IF-ELSE-ELSE IF**/
var naam= prompt('Geef uw naam in:');
var beroep=prompt ('Geef uw beroep in, maak een keuze: bediende, arbeider, werkloos');
if (beroep == 'bediende'){
	console.log('Het beroep van ' + naam + ' is ' + beroep);
}else if(beroep == 'arbeider'){
	console.log('Het beroep van ' + naam + ' is ' + beroep);
}else{
	console.log('Het beroep van ' + naam + ' is ' + beroep);
}

/**SHORTHAND NOTATIE**/
getal5 > getal6 ? 
	console.log(getal5 + ' is groter dan ' + getal6) : 
	console.log(getal5 + ' is kleiner dan ' + getal6);

/**SWITH STATEMENT**/
var onderwijs = 'vdab';
switch(onderwijs){
	case 'vdab':
		console.log('Gegeven door vdab');
		break;
	case 'syntra':
		console.log('Gegeven door syntra');
		break;
	case 'cvo':
		console.log('Gegeven door cvo');
		break;
	case 'vives':
		console.log('Gegeven door vives');
		break;
	default:
		console.log('Gegeven door een andere instelling')
}

/**FUNCTIONS**/
var huidigJaar = 2019;
function berekenLeeftijd(geboorteJaar){
	return huidigJaar - geboorteJaar;
}

var geboorteJaar = prompt('Geef uw geboortejaar in, YYYY:');
var resultaat = berekenLeeftijd(geboorteJaar);

if(resultaat >= 0){
	console.log(console.log('Het aantal jaren tussen ' + huidigJaar + ' en ' + geboorteJaar + ' is: ' + resultaat));
}else{

	console.log('Uw geboorteJaar kan niet groter zijn dan het huidige jaar.');
}

/**ARRAYS VULLEN**/
var cursisten = ['Tom', 'Tim', 'Bart','Els']; //eerste mogelijkheid
var cursusJaar = new Array(2017,2018,2019); //tweede mogelijkheid

console.log(cursisten); //opsomming van de cursisten
console.log(cursusJaar);//opsommming van de jaren
console.log(cursusJaar.length); //aantal jaren
console.log(cursisten.length); //aantal cursisten
console.log(cursisten[3]); //Els wordt afgebeeld
console.log(cursusJaar[0]); //2017 wordt afgebeeld

/**WIJZIGEN ARRAY DATA**/
cursisten[0] = 'Pieter'; //Tom wijzigt in Pieter
console.log(cursisten);

/**TOEVOEGEN VAN DATA AAN EEN ARRAY**/
cursisten.push('Marieke'); //aan het einde van de array
console.log(cursisten);
cursisten.unshift('Thomas'); //aan het begin van de array
console.log(cursisten);
cursisten.pop(); //verwijderd de laatste cursist van de array;
console.log(cursisten);
cursisten.shift();//verwijderd de eerste cursist van de array;

/**ophalen van het indexnummer (locatie) van de array**/
console.log(cursisten.indexOf('Bart')); //2 wordt afgebeeld;


/**OBJECTEN**/
/**OBJECTEN EN EIGENSCHAPPEN**/
/**OBJECT MAKEN EERSTE METHODE**/
var deelnemer= {
	voorNaam: 'Tom',
	familieNaam: 'Vanhoutte',
	geboorteJaar: 1973,
	kinderen: ['Emma', 'Elise'],
	gehuwd: true,
	berekenLeeftijd: function(){
		this.leeftijd = 2019 - this.geboorteJaar;
	}
};
console.log(deelnemer);
console.log(deelnemer.voorNaam);
console.log(deelnemer.familieNaam);


/**WIJZIGEN OBJECTEN**/
deelnemer.voorNaam = 'Tim';
console.log(deelnemer.voorNaam);

/**OBJECT MAKEN TWEEDE METHODE**/
var docent = new Object();
docent.voorNaam = 'Tom';
docent.geboorteJaar = 1973;

console.log(docent);

/**OBJECT METHODE AANSPREKEN**/

deelnemer.berekenLeeftijd();//berekent de leeftijd
console.log(deelnemer);// toont het volledige object met leeftijd.

/**lOOP**/
/**FOR LOOP**/
for(var i = 1; i <= 10; i++){
	console.log(i);
}

for(var i = 1; i <= 10; i+=2){
	console.log(i);
}

for(var i = 10; i > 1; i--){
	console.log(i);
}
/**FOR LOOP: ARRAY**/
var cursisten = ['Tom', 'Tim', 'Bart','Els'];
for(var i=1;i < cursisten.length; i++){
	console.log(cursisten[i]);
}
/**WHILE LOOP: ARRAY**/
var i = 0
while(i < cursisten.length){
	console.log(cursisten[i]);
	i++;
}

/**LOOP:CONTINUE**/
var data = ['Tim', 'Tom', 1980, 1973, 'designer', 'developer'];
for(var i = 0; i < data.length; i++){
	if(typeof data[i] === 'string') continue; //wanneer gelijk aan string DOE NIKS!
	console.log(data[i]); // wanneer verschillend van string, druk af!
}
/**LOOP:BREAK**/
var data = ['Tim', 'Tom', 1980, 1973, 'designer', 'developer'];
for(var i = 0; i < data.length; i++){
	if(typeof data[i] !== 'string') break; //springt uit de array wanneer verschillend van een string
	console.log(data[i]); // wanneer verschillend van string, druk af!
}



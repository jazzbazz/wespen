var naam = prompt('Vul uw naam in:', 'uw naam');
var weergave = 'De naam die u invoerde was:' + naam;
document.getElementById('resultaat').innerHTML = weergave;
var naam = prompt('Vul uw naam in:', 'uw naam');
var weergave = 'De naam die u invoerde was:' + naam;
document.querySelector('#resultaat').textContent = weergave;
document.querySelector('.basis').textContent = weergave;

for(i=1; i <= 3; i++){
	document.querySelector('.dynamisch' + i ).textContent = weergave + ' ' + i;
}
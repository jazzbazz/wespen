function Naam(){
	var naam = prompt('Vul uw naam in:', 'uw naam');
	var weergave = 'De naam die u invoerde was:' + naam;
	document.querySelector('#resultaat').textContent = weergave;
}


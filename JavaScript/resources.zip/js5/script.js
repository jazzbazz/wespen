window.onload = function(){
	document.querySelector('#resultaat').textContent = 'Het document is geladen';
}
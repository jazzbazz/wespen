window.onload = function(){
	var binnen = document.getElementById('binnen');
	var buiten = document.getElementById('buiten');
	var x = 0;
	var z = 0

	binnen.onmousemove = function(){ //bewegen van de muis
		binnen.innerHTML = x+=1;
	}
	binnen.onmouseover = function(){ //bewegen van de muis over een html element
		binnen.style.backgroundColor = '#FAC';
	}
	binnen.onmouseout = function(){ //verlaten van de muis van een html element
		buiten.innerHTML += 'De muis beweegt uit het vierkant<br>';
		binnen.style.backgroundColor = '#FFF';
	}
	binnen.onmousedown = function(){ //linkermuis ingedrukt
		binnen.innerHTML += z+=1;
	}
	binnen.onmouseleave = function(){ //verlaten html element
		binnen.innerHTML += z-=1;
	}

}
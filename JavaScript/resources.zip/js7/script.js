var numClicks = 0 //globale variable
window.onload = function(){
	var resultaat = document.getElementById('resultaat');
	document.getElementById('btnStart').addEventListener('click',function(){
			numClicks++;
			resultaat.innerHTML = numClicks + ' keer geklikt.';
	}, false);
}
var naam = '';//globale variable
window.onload = function(){
	var resultaat = document.getElementById('resultaat');
	//event handler voor de button
	document.getElementById('btnStart').addEventListener('click',function(){
			naam= document.getElementById('textNaam').value;
			resultaat.innerHTML = '<h5>Welkom ' + naam + '</h5>';
	}, false);
}
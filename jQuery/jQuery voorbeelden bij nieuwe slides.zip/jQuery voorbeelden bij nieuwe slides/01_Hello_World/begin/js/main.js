$(document).ready(function() {
	alert("hello world!");
});
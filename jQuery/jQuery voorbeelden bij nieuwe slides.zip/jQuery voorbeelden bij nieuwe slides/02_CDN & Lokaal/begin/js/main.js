$(document).ready(function() {
	// Your Script goes here
	alert('JQuery loaded');
});